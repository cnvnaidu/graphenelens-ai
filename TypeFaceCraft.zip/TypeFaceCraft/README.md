# GrapheneLens AI

![GrapheneLens AI](assets/app_logo.svg)

## Overview

GrapheneLens AI is an advanced eye analysis application designed to provide accurate, dataset-backed contact lens recommendations. The system analyzes eye conditions through image processing and combines this with user-reported symptoms to deliver personalized graphene-based lens recommendations optimized for your eye health.

## Key Features

- **AI-Powered Eye Analysis**: Upload eye or face images for intelligent condition detection
- **Personalized Lens Recommendations**: Receive tailored graphene lens suggestions based on your specific eye health needs
- **Symptom Tracking**: Report and track symptoms for more accurate recommendations
- **Detailed Explanations**: Get comprehensive information about recommended lens features and why they're suitable for you
- **Educational Resources**: Learn about graphene lens technology and eye health

## Technology Stack

- **Frontend**: Streamlit for a responsive and interactive user interface
- **Image Processing**: OpenCV and NumPy for advanced image analysis
- **Data Analysis**: Pandas for data management and analysis
- **AI Models**: Simulated diagnostic algorithms (with future plans for trained models)
- **Typography**: Custom fonts including DM Serif Display, Overpass Mono, and system fonts

## Installation and Setup

For detailed installation instructions, please refer to [setup_instructions.md](setup_instructions.md).

Quick start:
```bash
# Install dependencies
pip install streamlit numpy opencv-python pandas pillow

# Run the application
streamlit run app.py
```

## Deployment

For hosting and deployment options, see our [GitHub Hosting Guide](github_hosting_guide.md).

## Development Roadmap

- **Phase 1**: ✓ Core application with basic eye analysis and lens recommendations
- **Phase 2**: Enhanced AI models with increased accuracy and condition detection
- **Phase 3**: Historical tracking of eye conditions and recommendations
- **Phase 4**: Integration with wearable device data
- **Phase 5**: Prescription generation system for direct lens ordering

## Screenshots

(Screenshots will be added as the application develops)

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Disclaimer

GrapheneLens AI provides general recommendations based on image analysis and user-reported symptoms. It is not intended to replace professional medical advice, diagnosis, or treatment. Always consult with an eye care professional before making decisions about your eye health or vision correction options. The graphene lens technology described represents emerging innovations that may not yet be commercially available or FDA-approved for all described use cases.