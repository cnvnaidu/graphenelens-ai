import streamlit as st
import numpy as np
import cv2
from PIL import Image
import io
import base64

def preprocess_image(image_array):
    """
    Preprocess the uploaded image for analysis.
    
    Args:
        image_array: NumPy array of the image
        
    Returns:
        Preprocessed image ready for the model
    """
    try:
        # Convert to RGB if it's not
        if len(image_array.shape) == 2:  # Grayscale
            image_array = cv2.cvtColor(image_array, cv2.COLOR_GRAY2RGB)
        elif image_array.shape[2] == 4:  # RGBA
            image_array = cv2.cvtColor(image_array, cv2.COLOR_RGBA2RGB)
        
        # Resize to standard dimensions expected by most models
        resized_img = cv2.resize(image_array, (224, 224))
        
        # Apply some basic enhancements
        # Increase contrast
        lab = cv2.cvtColor(resized_img, cv2.COLOR_RGB2LAB)
        l, a, b = cv2.split(lab)
        clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8))
        cl = clahe.apply(l)
        enhanced_lab = cv2.merge((cl, a, b))
        enhanced_img = cv2.cvtColor(enhanced_lab, cv2.COLOR_LAB2RGB)
        
        return enhanced_img
        
    except Exception as e:
        st.error(f"Error in image preprocessing: {e}")
        return image_array  # Return original if processing fails

def load_and_resize_image(image_path, target_size=(224, 224)):
    """
    Load and resize an image from a file path.
    
    Args:
        image_path: Path to the image file
        target_size: Tuple of (width, height) for resizing
        
    Returns:
        Resized image as NumPy array
    """
    img = Image.open(image_path)
    img = img.resize(target_size)
    return np.array(img)

def display_lens_benefits(recommended_features):
    """
    Display benefits for the recommended lens features.
    
    Args:
        recommended_features: List of recommended lens features
    """
    benefits_mapping = {
        "EMI Shielding": "Protects eyes from digital screen radiation, reducing eye strain and potential cellular damage from long-term screen exposure.",
        
        "Hydration Retention": "Maintains moisture on the eye surface for longer periods, providing relief from dry eye symptoms and increased comfort throughout the day.",
        
        "Drug Delivery": "Gradually releases medication directly to the eye surface, ideal for post-surgery recovery or managing chronic conditions with consistent dosing.",
        
        "Glucose Monitoring": "Continuously tracks glucose levels through tear fluid, providing valuable health insights for diabetic users without invasive blood testing.",
        
        "Intraocular Pressure Sensing": "Monitors eye pressure throughout the day, helping to manage glaucoma and providing early detection of pressure spikes.",
        
        "UV Filtering": "Blocks harmful ultraviolet radiation, protecting against cataracts, macular degeneration, and other UV-related eye damage.",
        
        "Vision Correction": "Provides clear vision for those with refractive errors like myopia (nearsightedness) or hyperopia (farsightedness)."
    }
    
    for feature in recommended_features:
        if feature in benefits_mapping:
            st.markdown(f"**{feature}**: {benefits_mapping[feature]}")
