# Hosting GrapheneLens AI on GitHub - Complete Guide

This guide will walk you through hosting your GrapheneLens AI application on GitHub and deploying it through various platforms.

## Part 1: Setting Up Your GitHub Repository

### 1. Create a GitHub Repository

1. Sign in to [GitHub](https://github.com) or create an account if you don't have one
2. Click the "+" icon in the top-right corner and select "New repository"
3. Name your repository (e.g., "graphenelens-ai")
4. Add a description: "AI-powered application that recommends graphene contact lenses based on eye analysis"
5. Choose "Public" or "Private" visibility (Public is recommended for deployment services)
6. Select "Add a README file"
7. Click "Create repository"

### 2. Clone the Repository to Your Local Machine

```bash
git clone https://github.com/yourusername/graphenelens-ai.git
cd graphenelens-ai
```

### 3. Copy Your Project Files to the Repository

Copy all your project files to the repository folder. Your file structure should look like:

```
graphenelens-ai/
├── .streamlit/          # Streamlit configuration
├── assets/              # Application assets
├── app.py               # Main application file
├── lens_recommendations.py # Recommendation logic
├── models.py            # AI model simulations
├── utils.py             # Utility functions
├── .gitignore           # Git ignore file
├── LICENSE              # License file
├── Procfile             # For Heroku deployment
├── pyproject.toml       # Python project metadata
├── packages.txt         # System dependencies
├── README.md            # Repository readme
├── runtime.txt          # Python runtime specification
└── setup_instructions.md # Setup instructions
```

### 4. Push Your Code to GitHub

```bash
git add .
git commit -m "Initial commit of GrapheneLens AI application"
git push origin main
```

## Part 2: Deployment Options

Since GitHub Pages doesn't support running Python applications directly, here are several alternatives for deployment:

### Option 1: Streamlit Cloud (Recommended)

1. Visit [Streamlit Cloud](https://streamlit.io/cloud) and sign up/login with your GitHub account
2. Click "New app"
3. Select your GitHub repository and branch
4. In the advanced settings:
   - Select `app.py` as the main file
   - Leave the URL field as default
5. Click "Deploy"

Streamlit Cloud will automatically:
- Detect your requirements
- Install dependencies
- Deploy your application

### Option 2: Hugging Face Spaces

1. Create an account on [Hugging Face](https://huggingface.co/)
2. Go to your profile and select "Spaces"
3. Click "Create a Space"
4. Name your Space and select "Streamlit" as SDK
5. Connect your GitHub repository 
6. Configure build settings:
   - Set `app.py` as the main file

### Option 3: Heroku Deployment

1. Install the [Heroku CLI](https://devcenter.heroku.com/articles/heroku-cli)
2. Login to Heroku:
   ```bash
   heroku login
   ```
3. Create a new Heroku application:
   ```bash
   heroku create graphenelens-ai
   ```
4. Add the buildpacks:
   ```bash
   heroku buildpacks:add --index 1 heroku/python
   heroku buildpacks:add --index 2 https://github.com/heroku/heroku-buildpack-apt
   ```
5. Deploy to Heroku:
   ```bash
   git push heroku main
   ```

### Option 4: Render

1. Create an account on [Render](https://render.com/)
2. Connect your GitHub account
3. Create a new Web Service
4. Select your repository
5. Configure:
   - Build command: `pip install -r requirements.txt`
   - Start command: `streamlit run app.py`
6. Click "Create Web Service"

## Part 3: Maintaining Your GitHub Repository

### Making Updates

When you make changes to your code:

```bash
git add .
git commit -m "Description of your changes"
git push origin main
```

Most deployment services will automatically redeploy when you push changes.

### Creating Branches for Features

For new features, create a branch:

```bash
git checkout -b feature-name
# Make your changes
git add .
git commit -m "Added new feature"
git push origin feature-name
```

Then create a pull request on GitHub to merge into main.

### GitHub Actions for Automated Testing

You can create a `.github/workflows/test.yml` file to automatically test your application:

```yaml
name: Test Application

on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v2
    - name: Set up Python
      uses: actions/setup-python@v2
      with:
        python-version: '3.9'
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        if [ -f requirements.txt ]; then pip install -r requirements.txt; fi
    - name: Lint with flake8
      run: |
        pip install flake8
        flake8 . --count --select=E9,F63,F7,F82 --show-source --statistics
```

## Conclusion

By following this guide, you should be able to:
1. Host your GrapheneLens AI code on GitHub
2. Deploy the application using Streamlit Cloud, Hugging Face, Heroku, or Render
3. Maintain your repository with good practices

Remember that most cloud deployment platforms offer free tiers suitable for demonstration projects, but they may have limitations on usage and performance.