import numpy as np
import pandas as pd

def get_lens_recommendation(eye_conditions, symptoms):
    """
    Generates lens recommendations based on detected eye conditions and user symptoms.
    
    This function implements a rule-based system that would typically be implemented
    with a decision tree, random forest, or other ML model in production.
    
    Args:
        eye_conditions: Dictionary of eye conditions and their confidence scores
        symptoms: Dictionary of user-reported symptoms
        
    Returns:
        Dictionary containing lens recommendation details
    """
    # Define score thresholds
    MILD_THRESHOLD = 0.3
    MODERATE_THRESHOLD = 0.5
    SEVERE_THRESHOLD = 0.7
    
    # Initialize feature scores
    feature_scores = {
        "EMI Shielding": 0.0,
        "Hydration Retention": 0.0,
        "Drug Delivery": 0.0,
        "Glucose Monitoring": 0.0,
        "Intraocular Pressure Sensing": 0.0,
        "UV Filtering": 0.0,
        "Vision Correction": 0.0
    }
    
    # Process detected conditions from image analysis
    # EMI Shielding
    if eye_conditions["eye_strain"] > MILD_THRESHOLD:
        feature_scores["EMI Shielding"] += eye_conditions["eye_strain"] * 0.8
    
    # Hydration Retention
    if eye_conditions["dry_eye"] > MILD_THRESHOLD:
        feature_scores["Hydration Retention"] += eye_conditions["dry_eye"] * 0.9
    
    # Drug Delivery
    if eye_conditions["cataract"] > MODERATE_THRESHOLD:
        feature_scores["Drug Delivery"] += eye_conditions["cataract"] * 0.5
    
    # Glucose Monitoring
    if eye_conditions["diabetic_retinopathy"] > MILD_THRESHOLD:
        feature_scores["Glucose Monitoring"] += eye_conditions["diabetic_retinopathy"] * 0.8
    
    # Intraocular Pressure Sensing
    if eye_conditions["glaucoma"] > MILD_THRESHOLD:
        feature_scores["Intraocular Pressure Sensing"] += eye_conditions["glaucoma"] * 0.9
    
    # UV Filtering
    if eye_conditions["uv_damage"] > MILD_THRESHOLD:
        feature_scores["UV Filtering"] += eye_conditions["uv_damage"] * 0.8
    
    # Process user-reported symptoms
    
    # Screen time affects EMI Shielding
    if symptoms.get("screen_time", False):
        feature_scores["EMI Shielding"] += 0.7
    
    # Dry eyes affects Hydration Retention
    if symptoms.get("dry_eyes", False):
        feature_scores["Hydration Retention"] += 0.8
    
    # Diabetes affects Glucose Monitoring
    if symptoms.get("diabetes", False):
        feature_scores["Glucose Monitoring"] += 0.9
    
    # Glaucoma affects Intraocular Pressure Sensing
    if symptoms.get("glaucoma", False):
        feature_scores["Intraocular Pressure Sensing"] += 0.9
    
    # UV exposure affects UV Filtering
    if symptoms.get("uv_exposure", False):
        feature_scores["UV Filtering"] += 0.8
    
    # Vision correction needed
    if symptoms.get("vision_correction", False):
        feature_scores["Vision Correction"] += 0.9
    
    # Post-surgery affects Drug Delivery
    if symptoms.get("post_surgery", False):
        feature_scores["Drug Delivery"] += 0.9
    
    # Eye strain affects EMI Shielding
    if symptoms.get("eye_strain", False):
        feature_scores["EMI Shielding"] += 0.6
    
    # Consider profession
    profession = symptoms.get("profession", "")
    if profession == "Office/Computer Work":
        feature_scores["EMI Shielding"] += 0.5
        feature_scores["Hydration Retention"] += 0.3
    elif profession == "Outdoor Work":
        feature_scores["UV Filtering"] += 0.6
        feature_scores["Hydration Retention"] += 0.3
    elif profession == "Healthcare":
        feature_scores["EMI Shielding"] += 0.3
        feature_scores["Hydration Retention"] += 0.2
    elif profession == "Manufacturing/Industrial":
        feature_scores["UV Filtering"] += 0.3
        feature_scores["EMI Shielding"] += 0.2
    
    # Select top features (those scoring above MODERATE_THRESHOLD)
    recommended_features = []
    for feature, score in feature_scores.items():
        if score >= MODERATE_THRESHOLD:
            recommended_features.append(feature)
    
    # If no features meet the threshold, include the top 2
    if not recommended_features:
        top_features = sorted(feature_scores.items(), key=lambda x: x[1], reverse=True)[:2]
        recommended_features = [feature for feature, _ in top_features]
    
    # Generate a lens name based on top features
    lens_prefix = "GrapheneLens"
    if "EMI Shielding" in recommended_features and "Hydration Retention" in recommended_features:
        lens_name = f"{lens_prefix} Digital Comfort+"
    elif "Glucose Monitoring" in recommended_features:
        lens_name = f"{lens_prefix} DiabetaView"
    elif "Intraocular Pressure Sensing" in recommended_features:
        lens_name = f"{lens_prefix} PressureGuard"
    elif "UV Filtering" in recommended_features and "Vision Correction" in recommended_features:
        lens_name = f"{lens_prefix} OutdoorVision"
    elif "Drug Delivery" in recommended_features:
        lens_name = f"{lens_prefix} TherapeuticRelief"
    elif "Hydration Retention" in recommended_features:
        lens_name = f"{lens_prefix} HydraComfort"
    else:
        lens_name = f"{lens_prefix} CustomShield"
    
    # Generate a summary description
    summary = generate_lens_summary(recommended_features, symptoms)
    
    # Generate detailed explanation
    detailed_explanation = generate_detailed_explanation(recommended_features, eye_conditions, symptoms)
    
    # Return the full recommendation
    return {
        "lens_name": lens_name,
        "features": recommended_features,
        "detected_conditions": eye_conditions,
        "summary": summary,
        "detailed_explanation": detailed_explanation
    }

def generate_lens_summary(features, symptoms):
    """
    Generate a summary description for the recommended lens.
    
    Args:
        features: List of recommended features
        symptoms: Dictionary of user symptoms
        
    Returns:
        Summary string
    """
    # Base summary parts
    summary_parts = []
    
    if "EMI Shielding" in features:
        summary_parts.append("digital screen protection")
    
    if "Hydration Retention" in features:
        summary_parts.append("enhanced moisture retention")
    
    if "Drug Delivery" in features:
        summary_parts.append("therapeutic medication delivery")
    
    if "Glucose Monitoring" in features:
        summary_parts.append("glucose level tracking")
    
    if "Intraocular Pressure Sensing" in features:
        summary_parts.append("pressure monitoring")
    
    if "UV Filtering" in features:
        summary_parts.append("UV radiation protection")
    
    if "Vision Correction" in features:
        summary_parts.append("vision correction")
    
    # Combine the parts into a readable summary
    if len(summary_parts) == 1:
        features_text = summary_parts[0]
    elif len(summary_parts) == 2:
        features_text = f"{summary_parts[0]} and {summary_parts[1]}"
    else:
        features_text = ", ".join(summary_parts[:-1]) + f", and {summary_parts[-1]}"
    
    # Customize for specific user needs
    user_needs = []
    
    if symptoms.get("dry_eyes", False):
        user_needs.append("dry eye relief")
    
    if symptoms.get("screen_time", False):
        user_needs.append("high screen time protection")
    
    if symptoms.get("diabetes", False):
        user_needs.append("diabetes management")
    
    if symptoms.get("glaucoma", False):
        user_needs.append("glaucoma monitoring")
    
    if symptoms.get("post_surgery", False):
        user_needs.append("post-surgical care")
    
    if user_needs:
        if len(user_needs) == 1:
            needs_text = user_needs[0]
        elif len(user_needs) == 2:
            needs_text = f"{user_needs[0]} and {user_needs[1]}"
        else:
            needs_text = ", ".join(user_needs[:-1]) + f", and {user_needs[-1]}"
        
        summary = f"A specialized graphene lens with {features_text}, ideal for {needs_text}."
    else:
        summary = f"A specialized graphene lens with {features_text} for optimal eye health and comfort."
    
    return summary

def generate_detailed_explanation(features, eye_conditions, symptoms):
    """
    Generate a detailed explanation of the lens recommendation.
    
    Args:
        features: List of recommended features
        eye_conditions: Dictionary of detected eye conditions
        symptoms: Dictionary of user symptoms
        
    Returns:
        Detailed explanation as HTML-formatted string
    """
    explanation = ""
    
    # Start with detected conditions
    condition_explanations = []
    
    if eye_conditions["dry_eye"] > 0.5:
        condition_explanations.append("signs of dry eye")
    
    if eye_conditions["eye_strain"] > 0.5:
        condition_explanations.append("indicators of digital eye strain")
    
    if eye_conditions["glaucoma"] > 0.5:
        condition_explanations.append("potential glaucoma indicators")
    
    if eye_conditions["diabetic_retinopathy"] > 0.5:
        condition_explanations.append("possible diabetic retinopathy markers")
    
    if eye_conditions["cataract"] > 0.5:
        condition_explanations.append("early cataract development")
    
    if eye_conditions["uv_damage"] > 0.5:
        condition_explanations.append("signs of UV exposure damage")
    
    # Combine detected conditions
    if condition_explanations:
        if len(condition_explanations) == 1:
            explanation += f"Our analysis detected {condition_explanations[0]}. "
        else:
            conditions_text = ", ".join(condition_explanations[:-1]) + f", and {condition_explanations[-1]}"
            explanation += f"Our analysis detected {conditions_text}. "
    
    # Add explanations for each recommended feature
    for feature in features:
        if feature == "EMI Shielding":
            explanation += """
            <p><strong>EMI Shielding:</strong> The graphene layer in these lenses creates a protective barrier against electromagnetic radiation from digital screens. 
            This can help reduce oxidative stress in your eye cells and potentially slow digital-induced eye aging.</p>
            """
        
        elif feature == "Hydration Retention":
            explanation += """
            <p><strong>Hydration Retention:</strong> The specialized hydrophilic graphene oxide structure helps maintain moisture on your eye surface for up to 3 times longer than standard lenses.
            This creates consistent comfort throughout the day, especially in air-conditioned or dry environments.</p>
            """
        
        elif feature == "Drug Delivery":
            explanation += """
            <p><strong>Drug Delivery:</strong> Microscopic graphene reservoirs gradually release medication directly to your eye surface, 
            providing consistent therapeutic levels without the peaks and valleys of traditional eye drops.
            This is particularly beneficial for post-surgical healing or managing chronic eye conditions.</p>
            """
        
        elif feature == "Glucose Monitoring":
            explanation += """
            <p><strong>Glucose Monitoring:</strong> Embedded graphene-based sensors can detect glucose levels in your tear fluid, 
            providing non-invasive monitoring that can alert you to changes via a smartphone app.
            This allows for more frequent monitoring without finger pricks.</p>
            """
        
        elif feature == "Intraocular Pressure Sensing":
            explanation += """
            <p><strong>Intraocular Pressure Sensing:</strong> Micro-sensors in the lens can detect subtle changes in your eye pressure, 
            offering continuous monitoring for glaucoma management. The data collected creates a comprehensive pressure profile 
            throughout your day rather than the single point measurements taken during office visits.</p>
            """
        
        elif feature == "UV Filtering":
            explanation += """
            <p><strong>UV Filtering:</strong> Graphene's unique optical properties allow it to effectively block UV-A and UV-B radiation 
            while maintaining perfect visibility. This protection is integrated into the material itself rather than as a coating, 
            ensuring it won't wear off over time.</p>
            """
        
        elif feature == "Vision Correction":
            explanation += """
            <p><strong>Vision Correction:</strong> The lens incorporates precision optics for vision correction while maintaining 
            the benefits of graphene technology. The uniform thickness of graphene allows for ultra-thin lens profiles 
            with excellent optical clarity.</p>
            """
    
    # Add lifestyle recommendations
    explanation += """
    <p><strong>Lifestyle Recommendations:</strong></p>
    <ul>
    """
    
    if "EMI Shielding" in features:
        explanation += "<li>Consider implementing the 20-20-20 rule: every 20 minutes, look at something 20 feet away for 20 seconds.</li>"
    
    if "Hydration Retention" in features:
        explanation += "<li>Stay hydrated and consider using a humidifier in dry environments.</li>"
    
    if "Glucose Monitoring" in features:
        explanation += "<li>Regular comprehensive eye exams are particularly important for monitoring diabetic eye changes.</li>"
    
    if "Intraocular Pressure Sensing" in features:
        explanation += "<li>Avoid activities that increase eye pressure, such as certain yoga poses or heavy lifting.</li>"
    
    if "UV Filtering" in features:
        explanation += "<li>Continue to wear sunglasses outdoors as they provide additional protection for the entire eye area.</li>"
    
    explanation += """
    </ul>
    <p>Remember to consult with your eye care professional before starting any new lens regimen.</p>
    """
    
    return explanation


