import streamlit as st
import numpy as np
import pandas as pd
import io
import cv2
import os
import time
from PIL import Image
from utils import preprocess_image, display_lens_benefits, load_and_resize_image
from models import predict_eye_conditions
from lens_recommendations import get_lens_recommendation

# Set page configuration
st.set_page_config(
    page_title="GrapheneLens AI",
    page_icon="👁️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Add custom CSS for fonts
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=DM+Serif+Display&family=Overpass+Mono:wght@400;700&display=swap');
    @import url('https://cdn.jsdelivr.net/npm/typeface-gilroy@0.0.1/index.css');
    
    h1, h2, h3, h4, h5, h6 {
        font-family: 'DM Serif Display', serif !important; /* Using DM Serif Display as a substitute for Cirka */
    }
    
    .stMarkdown, p, div, label, .stSelectbox, .stNumberInput {
        font-family: 'Gilroy', 'Overpass Mono', sans-serif !important;
    }
    
    code {
        font-family: 'Overpass Mono', monospace !important;
    }
    
    .stButton>button {
        font-family: 'Gilroy', sans-serif !important;
        font-weight: 500;
    }
    
    .stTabs [data-baseweb="tab-list"] {
        font-family: 'Gilroy', sans-serif !important;
    }
    
    .stTabs [data-baseweb="tab"] {
        font-family: 'Gilroy', sans-serif !important;
    }
</style>
""", unsafe_allow_html=True)

# Initialize session state variables
if 'image_uploaded' not in st.session_state:
    st.session_state.image_uploaded = False
if 'processed_image' not in st.session_state:
    st.session_state.processed_image = None
if 'analysis_complete' not in st.session_state:
    st.session_state.analysis_complete = False
if 'recommendation' not in st.session_state:
    st.session_state.recommendation = None
if 'symptoms' not in st.session_state:
    st.session_state.symptoms = {}

def reset_app():
    st.session_state.image_uploaded = False
    st.session_state.processed_image = None
    st.session_state.analysis_complete = False
    st.session_state.recommendation = None
    st.session_state.symptoms = {}
    st.rerun()

# App header and introduction
st.title("GrapheneLens AI")
st.subheader("Advanced Eye Analysis & Graphene Lens Recommendation")

st.markdown("""
This AI-powered application analyzes your eye image and reported symptoms 
to recommend the ideal graphene-based contact lens customized for your specific needs.
""")

# Main content area
tab1, tab2, tab3 = st.tabs(["Upload & Symptoms", "Analysis Results", "About Graphene Lenses"])

# Tab 1: Upload & Symptoms
with tab1:
    col1, col2 = st.columns([2, 3])
    
    with col1:
        st.subheader("Upload Eye Image")
        uploaded_file = st.file_uploader("Upload a clear image of your eye or face", 
                                       type=["jpg", "jpeg", "png"], 
                                       help="For best results, use a clear, well-lit image of your eye. Fundus or OCT images are ideal, but clear face images work too.")
        
        if uploaded_file is not None:
            try:
                # Save the uploaded image to session state
                image = Image.open(uploaded_file)
                img_array = np.array(image)
                
                # Preprocess the image
                processed_img = preprocess_image(img_array)
                
                st.session_state.processed_image = processed_img
                st.session_state.image_uploaded = True
                
                # Display the uploaded image
                st.image(image, caption="Uploaded Image", use_column_width=True)
                
            except Exception as e:
                st.error(f"Error processing image: {e}")
                st.session_state.image_uploaded = False
    
    with col2:
        st.subheader("Symptom Questionnaire")
        st.markdown("Please select any symptoms or conditions you experience:")
        
        # Symptoms checklist
        col_a, col_b = st.columns(2)
        
        with col_a:
            st.session_state.symptoms["dry_eyes"] = st.checkbox("Dry eyes", help="Frequent feeling of dryness, irritation, or grittiness")
            st.session_state.symptoms["screen_time"] = st.checkbox("High screen time (4+ hours daily)", help="Regular extended exposure to digital screens")
            st.session_state.symptoms["diabetes"] = st.checkbox("Diabetes", help="Diagnosed with type 1 or type 2 diabetes")
            st.session_state.symptoms["glaucoma"] = st.checkbox("Glaucoma", help="Diagnosed with glaucoma or experiencing symptoms")
        
        with col_b:
            st.session_state.symptoms["uv_exposure"] = st.checkbox("High UV exposure", help="Regular outdoor activities or exposure to sunlight")
            st.session_state.symptoms["vision_correction"] = st.checkbox("Vision correction needed", help="Myopia, hyperopia, or astigmatism")
            st.session_state.symptoms["post_surgery"] = st.checkbox("Post-eye surgery", help="Recent eye surgery such as LASIK or cataract removal")
            st.session_state.symptoms["eye_strain"] = st.checkbox("Eye strain or fatigue", help="Frequent tiredness or strain in the eyes")
        
        # Additional information
        st.markdown("### Additional Information")
        age = st.number_input("Age", min_value=0, max_value=120, value=30, help="Your current age")
        
        profession_options = [
            "Office/Computer Work", 
            "Outdoor Work", 
            "Healthcare", 
            "Manufacturing/Industrial", 
            "Education", 
            "Other"
        ]
        profession = st.selectbox("Profession/Environment", options=profession_options, help="Your typical working environment")
        
        # Store additional info in session state
        st.session_state.symptoms["age"] = age
        st.session_state.symptoms["profession"] = profession
    
    # Analysis button
    if st.session_state.image_uploaded:
        if st.button("Analyze and Recommend Lens", type="primary"):
            with st.spinner("Analyzing your eye image and symptoms..."):
                # Progress bar for visual feedback
                progress_bar = st.progress(0)
                for i in range(100):
                    time.sleep(0.01)
                    progress_bar.progress(i + 1)
                
                # Perform eye condition prediction
                eye_conditions = predict_eye_conditions(st.session_state.processed_image)
                
                # Get lens recommendation based on predictions and symptoms
                recommendation = get_lens_recommendation(eye_conditions, st.session_state.symptoms)
                
                # Save results to session state
                st.session_state.recommendation = recommendation
                st.session_state.analysis_complete = True
                
                # Switch to the results tab
                st.info("Analysis complete! View your results in the 'Analysis Results' tab.")
    else:
        st.info("Please upload an eye or face image to proceed with the analysis.")

# Tab 2: Analysis Results
with tab2:
    if st.session_state.analysis_complete and st.session_state.recommendation:
        st.subheader("Your Eye Analysis Results")
        
        col1, col2 = st.columns([1, 2])
        
        with col1:
            if st.session_state.processed_image is not None:
                st.image(st.session_state.processed_image, caption="Processed Eye Image", use_column_width=True)
        
        with col2:
            st.markdown("### Detected Conditions")
            
            # Create a DataFrame for better visualization of the detected conditions
            conditions_data = []
            for condition, score in st.session_state.recommendation["detected_conditions"].items():
                formatted_condition = condition.replace("_", " ").title()
                confidence = f"{score:.1%}"
                severity = "High" if score > 0.7 else "Medium" if score > 0.4 else "Low"
                
                conditions_data.append({
                    "Condition": formatted_condition,
                    "Confidence": confidence,
                    "Severity": severity
                })
            
            df_conditions = pd.DataFrame(conditions_data)
            st.dataframe(df_conditions, use_container_width=True, hide_index=True)
        
        st.markdown("---")
        
        st.subheader("Graphene Lens Recommendation")
        st.markdown(f"### {st.session_state.recommendation['lens_name']}")
        
        st.markdown(f"**{st.session_state.recommendation['summary']}**")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("### Recommended Features")
            for feature in st.session_state.recommendation["features"]:
                st.markdown(f"✅ **{feature}**")
        
        with col2:
            st.markdown("### Benefits")
            display_lens_benefits(st.session_state.recommendation["features"])
        
        st.markdown("---")
        
        st.markdown("### Personalized Insights")
        st.write(st.session_state.recommendation["detailed_explanation"])
        
        if st.button("Start Over", key="reset_analysis"):
            reset_app()
    
    else:
        st.info("Please upload an image and complete the analysis to view your results.")
        if st.button("Go to Upload & Symptoms", key="goto_upload"):
            # Navigate to the Upload tab
            pass

# Tab 3: About Graphene Lenses
with tab3:
    st.subheader("About Graphene Lens Technology")
    
    st.markdown("""
    ### What are Graphene Contact Lenses?
    
    Graphene-based contact lenses represent a cutting-edge advancement in eye care technology. 
    These innovative lenses incorporate graphene – a single layer of carbon atoms arranged in a 
    hexagonal lattice – to provide exceptional properties and functionality beyond traditional 
    contact lenses.
    
    ### Key Features and Benefits
    
    **📡 EMI Shielding:**
    Graphene's conductive properties create a protective barrier against electromagnetic 
    interference (EMI) from digital screens, potentially reducing digital eye strain and 
    protecting sensitive eye tissues.
    
    **💧 Hydration Retention:**
    Enhanced water retention capabilities keep the lens surface moisturized for longer periods, 
    providing superior comfort for dry eye sufferers.
    
    **💊 Drug Delivery:**
    Specially designed graphene lenses can gradually release medications directly to the eye, 
    ideal for post-surgical care or chronic condition management.
    
    **📊 Biosensing Capabilities:**
    Built-in sensors can monitor glucose levels, intraocular pressure, and other biomarkers, 
    transmitting real-time health data to connected devices.
    
    **🛡️ UV Protection:**
    Superior UV filtering properties protect the eye from harmful solar radiation without 
    affecting visibility.
    
    **👓 Vision Correction:**
    Combined with traditional vision correction technology for myopia, hyperopia, and astigmatism.
    
    ### The Science Behind Graphene Lenses
    
    Graphene's unique atomic structure allows it to be:
    - Incredibly thin yet strong
    - Highly flexible and adaptable
    - Electrically conductive
    - Optically transparent
    - Biocompatible with eye tissues
    
    These properties make graphene an ideal material for next-generation contact lenses that 
    go beyond vision correction to provide therapeutic and diagnostic capabilities.
    """)
    
    st.markdown("---")
    
    st.markdown("""
    ### Disclaimer
    
    This application provides general recommendations based on image analysis and user-reported 
    symptoms. It is not intended to replace professional medical advice, diagnosis, or treatment. 
    Always consult with an eye care professional before making decisions about your eye health 
    or vision correction options.
    
    The graphene lens technology described represents emerging innovations that may not yet be 
    commercially available or FDA-approved for all described use cases.
    """)

# Footer
st.markdown("---")
st.markdown("© 2023 GrapheneLens AI • For educational purposes only • Not a medical device")
