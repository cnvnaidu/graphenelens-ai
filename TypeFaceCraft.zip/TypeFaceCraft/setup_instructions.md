# GrapheneLens AI Setup Instructions

This document provides detailed instructions for setting up and deploying the GrapheneLens AI application.

## Local Development Setup

### Prerequisites
- Python 3.9 or higher
- Git

### Installation Steps

1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/graphenelens-ai.git
   cd graphenelens-ai
   ```

2. **Create a virtual environment**
   ```bash
   # On Windows
   python -m venv venv
   venv\Scripts\activate

   # On macOS/Linux
   python3 -m venv venv
   source venv/bin/activate
   ```

3. **Install dependencies**
   ```bash
   pip install streamlit numpy opencv-python pandas pillow
   ```

4. **Run the application**
   ```bash
   streamlit run app.py
   ```

## GitHub Hosting

### Setting Up GitHub Repository

1. **Create a new repository on GitHub**
   - Go to GitHub and create a new repository

2. **Initialize Git and push to GitHub**
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/yourusername/graphenelens-ai.git
   git push -u origin main
   ```

### Deploying to GitHub Pages (Static Site)

GitHub Pages does not directly support running Python/Streamlit applications. Consider these alternatives:

## Alternative Deployment Options

### Deploying to Streamlit Cloud

1. **Create a Streamlit Cloud account**
   - Visit [streamlit.io/cloud](https://streamlit.io/cloud)

2. **Deploy from GitHub**
   - Connect your GitHub repository
   - Select the repository and branch
   - Configure deployment settings

### Deploying to Heroku

1. **Create a Procfile**
   Create a file named `Procfile` with:
   ```
   web: streamlit run app.py
   ```

2. **Create a runtime.txt**
   ```
   python-3.9.12
   ```

3. **Deploy to Heroku**
   ```bash
   heroku login
   heroku create graphenelens-ai
   git push heroku main
   ```

### Deploying to Hugging Face Spaces

1. **Create a Hugging Face account**

2. **Create a new Space**
   - Select Streamlit as the SDK
   - Connect your GitHub repository

3. **Configure requirements**
   - Make sure your repository includes a `requirements.txt` file

## File Structure

The application follows this file structure:

```
graphenelens-ai/
├── .streamlit/          # Streamlit configuration
│   └── config.toml      # Configuration settings
├── assets/              # Application assets
│   ├── app_logo.svg     # Logo for the application
│   ├── eye_diagram.svg  # Diagram of eye with graphene lens
│   └── lens_features.svg# Diagram of lens features
├── app.py               # Main application file
├── lens_recommendations.py # Recommendation logic
├── models.py            # AI model simulations
├── utils.py             # Utility functions
├── .gitignore           # Git ignore file
├── README.md            # Repository readme
└── setup_instructions.md# This file
```